// Copyright Epic Games, Inc. All Rights Reserved.

#include "CPP_BP.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, CPP_BP, "CPP_BP" );
