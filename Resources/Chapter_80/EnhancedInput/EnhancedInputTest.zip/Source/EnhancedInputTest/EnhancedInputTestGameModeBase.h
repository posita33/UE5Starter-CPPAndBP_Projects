// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "EnhancedInputTestGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class ENHANCEDINPUTTEST_API AEnhancedInputTestGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
};
